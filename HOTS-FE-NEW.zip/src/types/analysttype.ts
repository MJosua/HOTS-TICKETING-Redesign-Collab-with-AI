export interface Analyst {
    name: string;
    employee_id: number;
}


