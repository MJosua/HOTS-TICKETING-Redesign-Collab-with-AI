export interface srf_purpose {
    id: number;
    product_category: string;
    sub_category: string;
    purpose: string;
    active?: number;
    remarks?: string;
  }