export interface todaysweek {
    actualWeek: number;
    deliveryYear: number;
}

