export interface Country {
    country: string;
    country_id: number;
    employee_id: number;
}

