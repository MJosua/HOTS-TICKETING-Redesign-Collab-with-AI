export default function DefaultDashboard() {
    return <div className="text-gray-500">No custom module found.</div>;
  }
  