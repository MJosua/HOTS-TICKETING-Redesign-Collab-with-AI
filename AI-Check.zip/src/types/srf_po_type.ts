export interface srf_po_list {
    po_number: number;
  }
  
  
  
  
  