export interface skulist {
  label: string;
  filter1: string;
}




